const PORT = 3001
const fs = require('fs')
const path = require('path')
const { execSync } = require('child_process')

console.log(`🎬 Video Processor Service starting on port ${PORT}`)
console.log(`📡 Health check: http://localhost:${PORT}/health`)

// Path to yt-dlp binary
const YT_DLP_PATH = path.join(__dirname, 'yt-dlp')
console.log(`📹 yt-dlp path: ${YT_DLP_PATH}`)

// Create temp directory for downloads
const TEMP_DIR = path.join(process.cwd(), 'temp')
if (!fs.existsSync(TEMP_DIR)) {
  fs.mkdirSync(TEMP_DIR, { recursive: true })
}

// Cleanup old files on startup
fs.readdir(TEMP_DIR, (err, files) => {
  if (err) return
  files.forEach(file => {
    const filePath = path.join(TEMP_DIR, file)
    if (file.endsWith('.mp4') || file.endsWith('.txt') || file.endsWith('.part')) {
      try {
        fs.unlinkSync(filePath)
        console.log(`Cleaned up old file: ${file}`)
      } catch (e) {
        // Ignore errors
      }
    }
  })
})

Bun.serve({
  port: PORT,
  fetch: async (req) => {
    const url = new URL(req.url)

    // Handle CORS
    const corsHeaders = {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    }

    // Handle preflight requests
    if (req.method === 'OPTIONS') {
      return new Response(null, { headers: corsHeaders })
    }

    // Health check endpoint
    if (url.pathname === '/health') {
      // Check if yt-dlp is available
      let ytDlpAvailable = false
      try {
        execSync(`"${YT_DLP_PATH}" --version`, { stdio: 'pipe' })
        ytDlpAvailable = true
      } catch (e) {
        console.log('yt-dlp not available')
      }

      return Response.json(
        { 
          status: 'ok', 
          service: 'video-processor',
          ytDlpAvailable: ytDlpAvailable
        },
        { headers: corsHeaders }
      )
    }

    // Process video clip request
    if (url.pathname === '/process-clip' && req.method === 'POST') {
      try {
        const { videoId, startTime, endTime, title } = await req.json()

        if (!videoId || startTime === undefined || endTime === undefined) {
          return Response.json(
            { error: 'Missing required parameters' },
            { status: 400, headers: corsHeaders }
          )
        }

        const clipMetadata = {
          videoId,
          title: title || `Clip from ${videoId}`,
          startTime,
          endTime,
          duration: endTime - startTime,
          youtubeUrl: `https://www.youtube.com/watch?v=${videoId}`,
          createdAt: new Date().toISOString()
        }

        return Response.json(
          {
            success: true,
            metadata: clipMetadata,
            message: 'Clip metadata generated.'
          },
          { headers: corsHeaders }
        )
      } catch (error) {
        console.error('Error processing clip:', error)
        return Response.json(
          { error: 'Failed to process clip' },
          { status: 500, headers: corsHeaders }
        )
      }
    }

    // Download clip endpoint
    if (url.pathname === '/download-clip' && req.method === 'POST') {
      try {
        const { videoId, startTime, endTime, title } = await req.json()

        if (!videoId || startTime === undefined || endTime === undefined) {
          return Response.json(
            { error: 'Missing required parameters' },
            { status: 400, headers: corsHeaders }
          )
        }

        const clipId = `${videoId}-${startTime}-${endTime}-${Date.now()}`
        const outputFile = path.join(TEMP_DIR, `${clipId}.mp4`)
        const youtubeUrl = `https://www.youtube.com/watch?v=${videoId}`

        console.log(`Downloading clip: ${videoId} from ${startTime}s to ${endTime}s`)

        // Check if yt-dlp is available
        let ytDlpAvailable = false
        try {
          execSync(`"${YT_DLP_PATH}" --version`, { stdio: 'pipe' })
          ytDlpAvailable = true
          console.log('yt-dlp is available')
        } catch (e) {
          console.log('yt-dlp not found, will provide instructions')
        }

        if (ytDlpAvailable) {
          try {
            // Download with yt-dlp in full HD quality
            // Format selection: best video (MP4) + best audio, then fallback to best available
            // CRF 18 provides high quality (lower is better quality, 18 is visually lossless)
            const command = `"${YT_DLP_PATH}" -f "bestvideo[ext=mp4][height<=1080]+bestaudio[ext=m4a]/bestvideo[ext=mp4]+bestaudio/best[ext=mp4]/best" --download-sections "*${startTime}-${endTime}" --postprocessor-args "ffmpeg:-c:v libx264 -preset veryfast -crf 18 -c:a aac -b:a 192k" -o "${outputFile}" "${youtubeUrl}"`

            console.log('Executing yt-dlp command...')
            console.log(`Command: ${command.substring(0, 100)}...`)

            execSync(command, { 
              stdio: 'pipe',
              timeout: 300000 // 5 minute timeout
            })

            // Check if file was created
            if (fs.existsSync(outputFile)) {
              const fileBuffer = fs.readFileSync(outputFile)
              const stats = fs.statSync(outputFile)

              console.log(`✅ File created successfully, size: ${stats.size} bytes (${(stats.size / 1024 / 1024).toFixed(2)} MB)`)

              // Clean up after sending
              setTimeout(() => {
                try {
                  if (fs.existsSync(outputFile)) {
                    fs.unlinkSync(outputFile)
                    console.log(`Cleaned up file: ${clipId}`)
                  }
                } catch (e) {
                  console.error('Error cleaning up file:', e.message)
                }
              }, 60000) // Delete after 1 minute

              return new Response(fileBuffer, {
                headers: {
                  ...corsHeaders,
                  'Content-Type': 'video/mp4',
                  'Content-Disposition': `attachment; filename="clip-${clipId}.mp4"`,
                  'Content-Length': fileBuffer.length.toString(),
                },
              })
            } else {
              throw new Error('File was not created by yt-dlp')
            }
          } catch (error) {
            console.error('❌ Error with yt-dlp:', error.message)
            // Fall through to provide instructions
          }
        } else {
          console.log('yt-dlp not available, providing download instructions')
        }

        // Fallback: Provide detailed download instructions
        console.log('Providing download instructions as fallback')
        const infoText = `
Clip Download Instructions
==========================

Video Information:
- Video ID: ${videoId}
- Title: ${title || 'Untitled'}
- Start Time: ${startTime}s
- End Time: ${endTime}s
- Duration: ${endTime - startTime}s
- YouTube URL: ${youtubeUrl}

⚠️  DIRECT DOWNLOAD NOT AVAILABLE
The server doesn't have yt-dlp configured for direct video downloading.
Please use one of these methods to download the clip:

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📥 METHOD 1: Using yt-dlp (Recommended for Full HD)

Install yt-dlp:
  - Windows: Download from https://github.com/yt-dlp/yt-dlp/releases
  - Mac: brew install yt-dlp
  - Linux: sudo curl -L https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp -o /usr/local/bin/yt-dlp && sudo chmod +x /usr/local/bin/yt-dlp

Download the clip in Full HD:
  yt-dlp -f "bestvideo[ext=mp4][height<=1080]+bestaudio[ext=m4a]/best[ext=mp4]/best" --download-sections "*${startTime}-${endTime}" --postprocessor-args "ffmpeg:-c:v libx264 -preset veryfast -crf 18 -c:a aac -b:a 192k" "${youtubeUrl}" -o "clip-${clipId}.mp4"

This command downloads the best quality video (up to 1080p), extracts the clip from ${startTime}s to ${endTime}s, and encodes it with:
- Video codec: H.264 (libx264)
- Quality: CRF 18 (high quality, near lossless)
- Audio codec: AAC
- Audio bitrate: 192 kbps

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🌐 METHOD 2: Using Online Services

1. Download full video:
   - Visit: https://www.y2mate.com/youtube/${videoId}
   - Or: https://en.savefrom.net/1-youtube-video-downloader-4/?url=${youtubeUrl}
   - Select 1080p or highest available quality

2. Extract the clip:
   - Use video editing software (VLC, FFmpeg, DaVinci Resolve, etc.)
   - Set start point: ${startTime}s
   - Set end point: ${endTime}s
   - Export as MP4

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🎬 METHOD 3: Using Browser Extensions

1. Install a YouTube downloader extension:
   - Chrome: "Video DownloadHelper" or "YouTube Video Downloader"
   - Firefox: "Video DownloadHelper" or "1-Click YouTube Video Downloader"

2. Download the full video in highest quality

3. Use video editing software to extract the clip from ${startTime}s to ${endTime}s

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📱 METHOD 4: Using Mobile Apps

Android:
- Download "TubeMate" or "SnapTube"
- Download video in 1080p
- Use a video editor app to cut the clip

iOS:
- Use "Documents by Readdle" app
- Download YouTube video
- Use built-in video editor to extract clip

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💡 TIP: For best quality:
- Always download in 1080p or higher when available
- Use H.264 codec for maximum compatibility
- CRF 18-20 provides excellent quality with reasonable file size
- For social media, consider vertical/short format (9:16 aspect ratio)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

👨‍💻 Developed by: Humnath Pokharel
        `.trim()

        const buffer = Buffer.from(infoText, 'utf-8')

        console.log(`Sending download instructions, size: ${buffer.length} bytes`)

        return new Response(buffer, {
          headers: {
            ...corsHeaders,
            'Content-Type': 'text/plain',
            'Content-Disposition': `attachment; filename="download-instructions-${clipId}.txt"`,
            'Content-Length': buffer.length.toString(),
          },
        })

      } catch (error) {
        console.error('❌ Error downloading clip:', error)
        return Response.json(
          { error: 'Failed to download clip: ' + error.message },
          { status: 500, headers: corsHeaders }
        )
      }
    }

    // Get video info
    if (url.pathname === '/video-info' && req.method === 'POST') {
      try {
        const { videoId } = await req.json()

        if (!videoId) {
          return Response.json(
            { error: 'Missing videoId' },
            { status: 400, headers: corsHeaders }
          )
        }

        const videoInfo = {
          videoId,
          title: `Video ${videoId}`,
          thumbnail: `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`,
          duration: 600,
          url: `https://www.youtube.com/watch?v=${videoId}`
        }

        return Response.json(
          { success: true, info: videoInfo },
          { headers: corsHeaders }
        )
      } catch (error) {
        console.error('Error fetching video info:', error)
        return Response.json(
          { error: 'Failed to fetch video info' },
          { status: 500, headers: corsHeaders }
        )
      }
    }

    // 404 for unknown routes
    return Response.json(
      { error: 'Not found' },
      { status: 404, headers: corsHeaders }
    )
  }
})

console.log(`✅ Video Processor Service is running on port ${PORT}`)
console.log(`📁 Temp directory: ${TEMP_DIR}`)
