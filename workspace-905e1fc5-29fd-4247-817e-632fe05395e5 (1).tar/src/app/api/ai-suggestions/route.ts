import { NextRequest, NextResponse } from 'next/server'

export async function POST(request: NextRequest) {
  try {
    const { videoId, duration } = await request.json()

    if (!videoId || !duration) {
      return NextResponse.json(
        { error: 'Missing required parameters' },
        { status: 400 }
      )
    }

    // Generate AI-based clip suggestions
    // In a real implementation, this would use video analysis AI
    // For now, we'll generate intelligent suggestions based on video duration
    
    const suggestions: number[][] = []
    const segmentLength = Math.min(60, duration / 4) // Target 60s clips or 1/4 of video

    // Generate 3-5 suggestions
    const numSuggestions = Math.min(5, Math.floor(duration / 30))
    
    for (let i = 0; i < numSuggestions; i++) {
      // Start at different points in the video
      const startTime = (duration * (i + 1)) / (numSuggestions + 1) - segmentLength / 2
      const endTime = Math.min(startTime + segmentLength, duration)
      const adjustedStartTime = Math.max(0, startTime)
      
      suggestions.push([
        Math.round(adjustedStartTime),
        Math.round(endTime)
      ])
    }

    return NextResponse.json({ suggestions })
  } catch (error) {
    console.error('Error generating AI suggestions:', error)
    return NextResponse.json(
      { error: 'Failed to generate suggestions' },
      { status: 500 }
    )
  }
}
