import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(request: NextRequest) {
  try {
    const { videoId, title, startTime, endTime, thumbnail } = await request.json()

    if (!videoId || title === undefined || startTime === undefined || endTime === undefined) {
      return NextResponse.json(
        { error: 'Missing required parameters' },
        { status: 400 }
      )
    }

    const clip = await db.clip.create({
      data: {
        videoId,
        title,
        startTime,
        endTime,
        duration: endTime - startTime,
        thumbnail: thumbnail || `https://img.youtube.com/vi/${videoId}/mqdefault.jpg`,
        status: 'pending'
      }
    })

    return NextResponse.json({ success: true, clip })
  } catch (error) {
    console.error('Error saving clip:', error)
    return NextResponse.json(
      { error: 'Failed to save clip' },
      { status: 500 }
    )
  }
}

export async function GET() {
  try {
    const clips = await db.clip.findMany({
      orderBy: {
        createdAt: 'desc'
      }
    })

    return NextResponse.json({ success: true, clips })
  } catch (error) {
    console.error('Error fetching clips:', error)
    return NextResponse.json(
      { error: 'Failed to fetch clips' },
      { status: 500 }
    )
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json(
        { error: 'Missing clip id' },
        { status: 400 }
      )
    }

    await db.clip.delete({
      where: { id }
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting clip:', error)
    return NextResponse.json(
      { error: 'Failed to delete clip' },
      { status: 500 }
    )
  }
}
