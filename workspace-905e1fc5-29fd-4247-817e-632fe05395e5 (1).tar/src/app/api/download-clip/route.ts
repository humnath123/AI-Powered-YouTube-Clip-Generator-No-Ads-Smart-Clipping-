import { NextRequest, NextResponse } from 'next/server'

export async function POST(request: NextRequest) {
  try {
    const clip = await request.json()

    if (!clip.videoId || clip.startTime === undefined || clip.endTime === undefined) {
      return NextResponse.json(
        { error: 'Missing required clip parameters' },
        { status: 400 }
      )
    }

    // Call video processor service to download the clip
    const videoProcessorUrl = `http://localhost:3001/download-clip`

    console.log('Requesting clip download from video processor:', {
      videoId: clip.videoId,
      startTime: clip.startTime,
      endTime: clip.endTime,
      title: clip.title
    })

    const response = await fetch(videoProcessorUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        videoId: clip.videoId,
        startTime: clip.startTime,
        endTime: clip.endTime,
        title: clip.title
      })
    })

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ error: 'Unknown error' }))
      console.error('Video processor error:', errorData)
      return NextResponse.json(
        { error: 'Failed to download clip: ' + (errorData.error || 'Unknown error') },
        { status: response.status }
      )
    }

    // Get the content type from the response
    const contentType = response.headers.get('content-type') || 'video/mp4'
    const contentDisposition = response.headers.get('content-disposition') || `attachment; filename="clip-${clip.id}.mp4"`

    // Get the buffer
    const buffer = await response.arrayBuffer()

    // Log the file size for debugging
    console.log(`Downloaded file size: ${buffer.byteLength} bytes, Content-Type: ${contentType}`)

    // Check if it's a text file (fallback instructions)
    if (contentType.includes('text/plain') || buffer.byteLength < 1000) {
      console.log('Received text file instead of video - video processor may not have yt-dlp installed')
      // Still return the file as-is, it contains instructions
    }

    return new NextResponse(buffer, {
      headers: {
        'Content-Type': contentType,
        'Content-Disposition': contentDisposition,
        'Content-Length': buffer.byteLength.toString(),
      },
    })
  } catch (error) {
    console.error('Error downloading clip:', error)
    return NextResponse.json(
      { error: 'Failed to download clip: ' + (error instanceof Error ? error.message : 'Unknown error') },
      { status: 500 }
    )
  }
}
