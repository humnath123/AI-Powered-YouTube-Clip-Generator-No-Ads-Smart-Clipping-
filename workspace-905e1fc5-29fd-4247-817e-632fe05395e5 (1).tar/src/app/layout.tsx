import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as SonnerToaster } from "@/components/ui/sonner";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "ClipStudio - YouTube Video Viewer & Clip Creator",
  description: "Watch YouTube videos ad-free and create short clips for your channel. AI-powered clip suggestions and easy video editing.",
  keywords: ["ClipStudio", "YouTube", "video editor", "clip creator", "shorts", "video clips", "AI clips"],
  authors: [{ name: "ClipStudio Team" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "ClipStudio - YouTube Video Viewer & Clip Creator",
    description: "Watch YouTube videos ad-free and create amazing clips with AI suggestions",
    url: "https://chat.z.ai",
    siteName: "ClipStudio",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "ClipStudio - YouTube Video Viewer & Clip Creator",
    description: "Watch YouTube videos ad-free and create amazing clips",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
        <SonnerToaster />
      </body>
    </html>
  );
}
