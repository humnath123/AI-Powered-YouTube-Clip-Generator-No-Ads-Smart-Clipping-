'use client'

import { useState, useRef, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Slider } from '@/components/ui/slider'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import { Play, Pause, Scissors, Download, Sparkles, Clock, Film, Youtube, Zap, RefreshCw, Video, Share2, Heart, TrendingUp } from 'lucide-react'
import { toast } from 'sonner'

// Extend Window interface for YouTube API
declare global {
  interface Window {
    YT: any
    onYouTubeIframeAPIReady: () => void
  }
}

interface VideoClip {
  id: string
  videoId: string
  title: string
  startTime: number
  endTime: number
  thumbnail?: string
}

export default function Home() {
  const [videoUrl, setVideoUrl] = useState('')
  const [videoId, setVideoId] = useState('')
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentTime, setCurrentTime] = useState(0)
  const [duration, setDuration] = useState(0)
  const [clipStart, setClipStart] = useState(0)
  const [clipEnd, setClipEnd] = useState(0)
  const [selectedClips, setSelectedClips] = useState<VideoClip[]>([])
  const [videoTitle, setVideoTitle] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [isGeneratingClip, setIsGeneratingClip] = useState(false)
  const [aiSuggestions, setAiSuggestions] = useState<number[][]>([])
  const [isPlayerReady, setIsPlayerReady] = useState(false)

  const playerRef = useRef<any>(null)

  const extractVideoId = (url: string): string | null => {
    const patterns = [
      /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([^&\n?#]+)/,
      /^([a-zA-Z0-9_-]{11})$/
    ]
    for (const pattern of patterns) {
      const match = url.match(pattern)
      if (match) return match[1]
    }
    return null
  }

  const loadVideo = () => {
    const id = extractVideoId(videoUrl)
    if (!id) {
      toast.error('Invalid YouTube URL')
      return
    }

    // Destroy existing player if any
    if (playerRef.current && typeof playerRef.current.destroy === 'function') {
      playerRef.current.destroy()
      playerRef.current = null
    }

    setVideoId(id)
    setIsLoading(true)
    setIsPlayerReady(false)
    setIsPlaying(false)
    setCurrentTime(0)
    setDuration(0)
    setClipStart(0)
    setClipEnd(0)
    setSelectedClips([])
    setAiSuggestions([])

    console.log('Loading video:', id)
  }

  // Load YouTube API script once
  useEffect(() => {
    if (!document.getElementById('youtube-iframe-api')) {
      const tag = document.createElement('script')
      tag.id = 'youtube-iframe-api'
      tag.src = 'https://www.youtube.com/iframe_api'
      const firstScriptTag = document.getElementsByTagName('script')[0]
      firstScriptTag.parentNode?.insertBefore(tag, firstScriptTag)
      console.log('YouTube API script loaded')
    }
  }, [])

  // Initialize player when videoId changes
  useEffect(() => {
    if (videoId) {
      console.log('Initializing player for video:', videoId)
      setIsLoading(true)
      setIsPlayerReady(false)

      // Wait for API to be ready
      const initializePlayer = (retryCount = 0) => {
        if (typeof (window as any).YT !== 'undefined' && (window as any).YT.Player) {
          console.log('YouTube API is ready, creating player...')
          try {
            // Destroy existing player if any
            if (playerRef.current && typeof playerRef.current.destroy === 'function') {
              console.log('Destroying existing player')
              playerRef.current.destroy()
              playerRef.current = null
            }

            // Create a new player that will replace the div
            playerRef.current = new (window as any).YT.Player('youtube-player-container', {
              videoId,
              height: '100%',
              width: '100%',
              playerVars: {
                autoplay: 0,
                controls: 1,
                modestbranding: 1,
                rel: 0,
                showinfo: 0,
                ecver: 2,
                iv_load_policy: 3,
                playsinline: 1,
                enablejsapi: 1,
                origin: window.location.origin,
              },
              events: {
                onReady: (event: any) => {
                  console.log('YouTube player ready')
                  const playerDuration = event.target.getDuration()
                  setDuration(playerDuration)
                  setClipEnd(playerDuration)
                  setIsLoading(false)
                  setIsPlayerReady(true)
                  toast.success('Video loaded successfully!')
                },
                onStateChange: (event: any) => {
                  console.log('Player state changed:', event.data)
                  setIsPlaying(event.data === 1)
                },
                onError: (event: any) => {
                  console.error('YouTube player error:', event.data)
                  setIsLoading(false)
                  setIsPlayerReady(false)
                  const errorMessage = event.data === 2 ? 'Invalid video ID' : 'Failed to load video'
                  toast.error(errorMessage + '. Please try a different video.')
                }
              }
            })
          } catch (error) {
            console.error('Error initializing player:', error)
            setIsLoading(false)
            setIsPlayerReady(false)
            toast.error('Failed to initialize player. Please try again.')
          }
        } else if (retryCount < 50) {
          // API not ready yet, try again (max 5 seconds)
          console.log(`YouTube API not ready, retrying... (${retryCount}/50)`)
          setTimeout(() => initializePlayer(retryCount + 1), 100)
        } else {
          console.error('YouTube API failed to load after 5 seconds')
          setIsLoading(false)
          setIsPlayerReady(false)
          toast.error('YouTube API failed to load. Please refresh the page.')
        }
      }

      // Give the DOM a moment to render the container
      setTimeout(() => initializePlayer(), 100)

      // Cleanup function
      return () => {
        if (playerRef.current && typeof playerRef.current.destroy === 'function') {
          console.log('Cleaning up player')
          playerRef.current.destroy()
          playerRef.current = null
        }
      }
    }
  }, [videoId])

  // Load saved clips from database
  useEffect(() => {
    loadSavedClips()
  }, [])

  const loadSavedClips = async () => {
    try {
      const response = await fetch('/api/save-clip?XTransformPort=3000')
      if (response.ok) {
        const data = await response.json()
        if (data.success && data.clips) {
          setSelectedClips(data.clips.map((clip: any) => ({
            id: clip.id,
            videoId: clip.videoId,
            title: clip.title,
            startTime: clip.startTime,
            endTime: clip.endTime,
            thumbnail: clip.thumbnail
          })))
        }
      }
    } catch (error) {
      console.error('Error loading saved clips:', error)
    }
  }

  useEffect(() => {
    if (isPlayerReady && playerRef.current && typeof playerRef.current.getCurrentTime === 'function') {
      const interval = setInterval(() => {
        if (isPlaying && playerRef.current && isPlayerReady) {
          try {
            const time = playerRef.current.getCurrentTime()
            if (typeof time === 'number') {
              setCurrentTime(time)
            }
          } catch (error) {
            console.error('Error getting current time:', error)
          }
        }
      }, 100)
      return () => clearInterval(interval)
    }
  }, [isPlaying, isPlayerReady])

  const handlePlayPause = () => {
    if (!playerRef.current || !isPlayerReady) {
      toast.error('Player is not ready yet. Please wait.')
      return
    }

    if (typeof playerRef.current.playVideo !== 'function' || typeof playerRef.current.pauseVideo !== 'function') {
      return
    }

    if (isPlaying) {
      playerRef.current.pauseVideo()
    } else {
      playerRef.current.playVideo()
    }
  }

  const handleSeek = (value: number[]) => {
    if (!playerRef.current || !isPlayerReady) return
    if (typeof playerRef.current.seekTo !== 'function') return

    playerRef.current.seekTo(value[0], true)
    setCurrentTime(value[0])
  }

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60)
    const secs = Math.floor(seconds % 60)
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  const setClipStartTime = () => {
    setClipStart(currentTime)
    toast.success(`Clip start set to ${formatTime(currentTime)}`)
  }

  const setClipEndTime = () => {
    setClipEnd(currentTime)
    toast.success(`Clip end set to ${formatTime(currentTime)}`)
  }

  const createClip = async () => {
    if (clipEnd <= clipStart) {
      toast.error('End time must be after start time')
      return
    }

    const clip: VideoClip = {
      id: Date.now().toString(),
      videoId,
      title: videoTitle || `Clip from ${videoId}`,
      startTime: clipStart,
      endTime: clipEnd,
      thumbnail: `https://img.youtube.com/vi/${videoId}/mqdefault.jpg`
    }

    // Save to database
    try {
      const response = await fetch('/api/save-clip?XTransformPort=3000', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          videoId: clip.videoId,
          title: clip.title,
          startTime: clip.startTime,
          endTime: clip.endTime,
          thumbnail: clip.thumbnail
        })
      })

      if (response.ok) {
        const data = await response.json()
        if (data.success && data.clip) {
          clip.id = data.clip.id // Use the database ID
        }
      }
    } catch (error) {
      console.error('Error saving clip to database:', error)
    }

    setSelectedClips([...selectedClips, clip])
    toast.success('Clip created successfully!')
  }

  const deleteClip = async (clipId: string) => {
    // Delete from database
    try {
      await fetch(`/api/save-clip?id=${clipId}&XTransformPort=3000`, {
        method: 'DELETE'
      })
    } catch (error) {
      console.error('Error deleting clip from database:', error)
    }

    setSelectedClips(selectedClips.filter(clip => clip.id !== clipId))
    toast.success('Clip deleted')
  }

  const downloadAISuggestion = async (suggestion: number[], index: number) => {
    const clip: VideoClip = {
      id: `ai-${Date.now()}-${index}`,
      videoId,
      title: `AI Suggested Clip #${index + 1}`,
      startTime: suggestion[0],
      endTime: suggestion[1],
      thumbnail: `https://img.youtube.com/vi/${videoId}/mqdefault.jpg`
    }

    toast.info('Preparing AI clip for download...')
    try {
      const response = await fetch(`/api/download-clip?XTransformPort=3000`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(clip)
      })

      if (response.ok) {
        const blob = await response.blob()
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url
        a.download = `ai-clip-${index + 1}.mp4`
        document.body.appendChild(a)
        a.click()
        window.URL.revokeObjectURL(url)
        document.body.removeChild(a)
        toast.success('AI clip downloaded successfully!')
      } else {
        toast.error('Failed to download AI clip')
      }
    } catch (error) {
      toast.error('Error downloading AI clip')
    }
  }

  const generateAIClips = async () => {
    if (!videoId || !duration || duration === 0) {
      toast.error('Please load a video first and wait for it to be ready')
      return
    }

    setIsGeneratingClip(true)
    try {
      const response = await fetch(`/api/ai-suggestions?XTransformPort=3000`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ videoId, duration })
      })

      if (response.ok) {
        const data = await response.json()
        setAiSuggestions(data.suggestions || [])
        toast.success('AI suggestions generated! Check the AI tab.')
      } else {
        toast.error('Failed to generate AI suggestions')
      }
    } catch (error) {
      toast.error('Error generating AI suggestions')
    } finally {
      setIsGeneratingClip(false)
    }
  }

  const downloadClip = async (clip: VideoClip) => {
    toast.info('Preparing clip for download...')
    try {
      const response = await fetch(`/api/download-clip?XTransformPort=3000`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(clip)
      })

      if (response.ok) {
        const blob = await response.blob()
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url
        a.download = `clip-${clip.id}.mp4`
        document.body.appendChild(a)
        a.click()
        window.URL.revokeObjectURL(url)
        document.body.removeChild(a)
        toast.success('Clip downloaded successfully!')
      } else {
        toast.error('Failed to download clip')
      }
    } catch (error) {
      toast.error('Error downloading clip')
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 dark:from-slate-950 dark:via-purple-950 dark:to-slate-950">
      {/* Animated Background Elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-purple-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-pink-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-2000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-blue-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-4000"></div>
      </div>

      {/* Header */}
      <header className="border-b border-white/10 bg-black/30 backdrop-blur-xl sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative group">
                <div className="absolute inset-0 bg-gradient-to-r from-red-500 to-orange-500 rounded-xl blur-lg opacity-50 group-hover:opacity-75 transition-opacity"></div>
                <div className="relative bg-gradient-to-br from-red-500 to-orange-600 p-2.5 rounded-xl shadow-lg">
                  <Youtube className="w-6 h-6 text-white" />
                </div>
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-white via-purple-200 to-pink-200 bg-clip-text text-transparent">
                  ClipStudio
                </h1>
                <p className="text-xs text-purple-300/70 font-medium">AI-Powered YouTube Clip Creator</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="bg-white/5 border-white/10 text-purple-200">
                <Zap className="w-3 h-3 mr-1 text-yellow-400" />
                AI Ready
              </Badge>
            </div>
          </div>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-8 max-w-7xl relative z-10">
        {/* URL Input Card */}
        <Card className="mb-8 bg-white/5 border-white/10 backdrop-blur-xl shadow-2xl overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-red-500 via-purple-500 to-pink-500"></div>
          <CardHeader className="pb-4">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2 text-white">
                  <Video className="w-5 h-5 text-purple-400" />
                  Load YouTube Video
                </CardTitle>
                <CardDescription className="text-purple-300/70 mt-1">
                  Paste a YouTube URL to watch ad-free and create stunning clips
                </CardDescription>
              </div>
              <div className="flex gap-2">
                <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 border-0 text-white">
                  <TrendingUp className="w-3 h-3 mr-1" />
                  No Ads
                </Badge>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex gap-3">
              <div className="relative flex-1">
                <Input
                  placeholder="https://www.youtube.com/watch?v=..."
                  value={videoUrl}
                  onChange={(e) => setVideoUrl(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && loadVideo()}
                  className="flex-1 bg-white/5 border-white/10 text-white placeholder:text-purple-300/50 focus:border-purple-500 focus:ring-purple-500/20 pr-12"
                />
                {videoUrl && (
                  <Button
                    onClick={() => setVideoUrl('')}
                    variant="ghost"
                    size="sm"
                    className="absolute right-2 top-1/2 -translate-y-1/2 h-8 w-8 p-0 hover:bg-white/10"
                  >
                    <RefreshCw className="w-4 h-4 text-purple-300/50" />
                  </Button>
                )}
              </div>
              <Button
                onClick={loadVideo}
                disabled={!videoUrl || isLoading}
                className="min-w-[140px] bg-gradient-to-r from-red-500 to-orange-500 hover:from-red-600 hover:to-orange-600 text-white font-semibold shadow-lg shadow-red-500/25"
              >
                {isLoading ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    Loading...
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 mr-2" />
                    Load Video
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {videoId && (
          <div className="grid lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-6">
              {/* Video Player Card */}
              <Card className="bg-white/5 border-white/10 backdrop-blur-xl shadow-2xl overflow-hidden">
                <div className="relative aspect-video bg-black/80 rounded-t-lg overflow-hidden">
                  {isLoading && (
                    <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-purple-900/50 to-pink-900/50 z-10 backdrop-blur-sm">
                      <div className="text-center">
                        <div className="relative">
                          <div className="animate-spin rounded-full h-16 w-16 border-4 border-purple-500/30 border-t-purple-500 mx-auto mb-4"></div>
                          <div className="absolute inset-0 animate-ping rounded-full h-16 w-16 border-2 border-purple-500/50 mx-auto"></div>
                        </div>
                        <p className="text-white font-medium text-lg">Loading video...</p>
                        <p className="text-purple-300/70 text-sm mt-1">Please wait while we prepare your video</p>
                      </div>
                    </div>
                  )}
                  <div
                    id="youtube-player-container"
                    className="w-full h-full"
                  ></div>
                </div>
              </Card>

              {/* Video Controls Card */}
              <Card className="bg-white/5 border-white/10 backdrop-blur-xl shadow-2xl">
                <CardContent className="pt-6 space-y-6">
                  {/* Play/Pause and Timeline */}
                  <div className="space-y-4">
                    <div className="flex items-center gap-4">
                      <Button
                        onClick={handlePlayPause}
                        size="lg"
                        className="w-16 h-16 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 shadow-lg shadow-purple-500/25 border-2 border-white/20"
                        disabled={!isPlayerReady}
                      >
                        {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6 ml-1" />}
                      </Button>
                      <div className="flex-1 space-y-3">
                        <Slider
                          value={[currentTime]}
                          onValueChange={handleSeek}
                          max={duration}
                          step={0.1}
                          className="cursor-pointer"
                          disabled={!isPlayerReady}
                        />
                        <div className="flex justify-between text-sm text-purple-300/70">
                          <span className="font-mono">{formatTime(currentTime)}</span>
                          <span className="font-mono">{formatTime(duration)}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <Separator className="bg-white/10" />

                  {/* Clip Creation */}
                  <div className="space-y-4">
                    <h3 className="text-white font-semibold flex items-center gap-2">
                      <div className="bg-gradient-to-r from-purple-500 to-pink-500 p-1.5 rounded-lg">
                        <Scissors className="w-4 h-4 text-white" />
                      </div>
                      Create Custom Clip
                    </h3>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-sm font-medium text-purple-300/70">Start Time</label>
                        <div className="flex gap-2">
                          <Input
                            value={formatTime(clipStart)}
                            readOnly
                            className="bg-white/5 border-white/10 text-white font-mono"
                          />
                          <Button
                            onClick={setClipStartTime}
                            variant="outline"
                            size="icon"
                            className="border-white/20 hover:bg-white/10 hover:border-purple-500/50"
                          >
                            <Clock className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium text-purple-300/70">End Time</label>
                        <div className="flex gap-2">
                          <Input
                            value={formatTime(clipEnd)}
                            readOnly
                            className="bg-white/5 border-white/10 text-white font-mono"
                          />
                          <Button
                            onClick={setClipEndTime}
                            variant="outline"
                            size="icon"
                            className="border-white/20 hover:bg-white/10 hover:border-purple-500/50"
                          >
                            <Clock className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                    <Button
                      onClick={createClip}
                      className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-semibold shadow-lg shadow-purple-500/25 h-12 text-base"
                      size="lg"
                    >
                      <Scissors className="w-5 h-5 mr-2" />
                      Create Clip ({formatTime(clipEnd - clipStart)})
                    </Button>
                  </div>

                  <Separator className="bg-white/10" />

                  {/* AI Suggestions Button */}
                  <Button
                    onClick={generateAIClips}
                    disabled={isGeneratingClip || !isPlayerReady}
                    variant="outline"
                    className="w-full bg-gradient-to-r from-yellow-500/20 to-orange-500/20 border-yellow-500/30 hover:bg-yellow-500/30 hover:border-yellow-500/50 text-white font-semibold h-12 text-base"
                  >
                    {isGeneratingClip ? (
                      <>
                        <RefreshCw className="w-5 h-5 mr-2 animate-spin" />
                        Analyzing Video...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-5 h-5 mr-2" />
                        Generate AI Clip Suggestions
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>
            </div>

            <div className="space-y-6">
              {/* Your Clips Card */}
              <Card className="bg-white/5 border-white/10 backdrop-blur-xl shadow-2xl">
                <CardHeader className="pb-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-white flex items-center gap-2">
                        <Video className="w-5 h-5 text-purple-400" />
                        Your Clips
                      </CardTitle>
                      <CardDescription className="text-purple-300/70 mt-1">
                        {selectedClips.length} clip{selectedClips.length !== 1 ? 's' : ''} created
                      </CardDescription>
                    </div>
                    {selectedClips.length > 0 && (
                      <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 border-0 text-white">
                        {selectedClips.length}
                      </Badge>
                    )}
                  </div>
                </CardHeader>
                <CardContent>
                  {selectedClips.length === 0 ? (
                    <div className="text-center py-12 px-4">
                      <div className="relative mb-4">
                        <div className="absolute inset-0 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full blur-xl opacity-20"></div>
                        <div className="relative bg-gradient-to-br from-purple-500/20 to-pink-500/20 w-20 h-20 rounded-full flex items-center justify-center mx-auto">
                          <Scissors className="w-10 h-10 text-purple-300" />
                        </div>
                      </div>
                      <p className="text-purple-300/70 font-medium">No clips created yet</p>
                      <p className="text-purple-300/50 text-sm mt-1">Create your first clip above!</p>
                    </div>
                  ) : (
                    <ScrollArea className="h-[400px] pr-4">
                      <div className="space-y-3">
                        {selectedClips.map((clip) => (
                          <Card key={clip.id} className="group overflow-hidden bg-white/5 border-white/10 hover:border-purple-500/50 transition-all hover:shadow-lg hover:shadow-purple-500/10">
                            <div className="aspect-video bg-gradient-to-br from-purple-900/30 to-pink-900/30 relative overflow-hidden">
                              <img
                                src={clip.thumbnail}
                                alt="Clip thumbnail"
                                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                              />
                              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
                              <div className="absolute bottom-2 right-2 bg-gradient-to-r from-purple-500 to-pink-500 text-white px-3 py-1 rounded-lg text-xs font-semibold shadow-lg">
                                {formatTime(clip.endTime - clip.startTime)}
                              </div>
                            </div>
                            <CardContent className="p-3 space-y-2">
                              <div className="flex items-center justify-between">
                                <div className="text-xs text-purple-300/70 font-mono">
                                  {formatTime(clip.startTime)} - {formatTime(clip.endTime)}
                                </div>
                              </div>
                              <div className="flex gap-2">
                                <Button
                                  onClick={() => downloadClip(clip)}
                                  size="sm"
                                  className="flex-1 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white text-xs h-9"
                                >
                                  <Download className="w-3 h-3 mr-1" />
                                  Download
                                </Button>
                                <Button
                                  onClick={() => deleteClip(clip.id)}
                                  size="sm"
                                  variant="outline"
                                  className="border-white/20 hover:bg-red-500/20 hover:border-red-500/50 hover:text-red-400 text-xs h-9 w-20"
                                >
                                  Delete
                                </Button>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </ScrollArea>
                  )}
                </CardContent>
              </Card>

              {/* AI Suggestions Card */}
              {aiSuggestions.length > 0 && (
                <Card className="bg-gradient-to-br from-yellow-500/10 to-orange-500/10 border-yellow-500/20 backdrop-blur-xl shadow-2xl">
                  <CardHeader className="pb-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="text-white flex items-center gap-2">
                          <div className="relative">
                            <div className="absolute inset-0 bg-gradient-to-r from-yellow-500 to-orange-500 blur-lg opacity-30"></div>
                            <Sparkles className="w-5 h-5 text-yellow-400 relative" />
                          </div>
                          AI Suggestions
                        </CardTitle>
                        <CardDescription className="text-yellow-300/70 mt-1">
                          {aiSuggestions.length} smart clip recommendations
                        </CardDescription>
                      </div>
                      <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 border-0 text-white animate-pulse">
                        AI
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-[400px] pr-4">
                      <div className="space-y-3">
                        {aiSuggestions.map((suggestion, index) => (
                          <Card
                            key={index}
                            className="group overflow-hidden bg-white/5 border-yellow-500/20 hover:border-yellow-500/50 transition-all hover:shadow-lg hover:shadow-yellow-500/10"
                          >
                            <div className="aspect-video bg-gradient-to-br from-yellow-900/30 to-orange-900/30 relative overflow-hidden">
                              <img
                                src={`https://img.youtube.com/vi/${videoId}/mqdefault.jpg`}
                                alt="Clip thumbnail"
                                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                              />
                              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
                              <div className="absolute top-2 left-2 bg-gradient-to-r from-yellow-500 to-orange-500 text-white px-2 py-1 rounded-md text-xs font-bold shadow-lg">
                                #{index + 1}
                              </div>
                              <div className="absolute bottom-2 right-2 bg-black/80 text-white px-3 py-1 rounded-lg text-xs font-semibold shadow-lg backdrop-blur-sm">
                                {formatTime(suggestion[1] - suggestion[0])}
                              </div>
                            </div>
                            <CardContent className="p-3 space-y-2">
                              <div className="text-xs text-yellow-300/70 font-mono">
                                {formatTime(suggestion[0])} - {formatTime(suggestion[1])}
                              </div>
                              <div className="flex gap-2">
                                <Button
                                  onClick={(e) => {
                                    e.stopPropagation()
                                    setClipStart(suggestion[0])
                                    setClipEnd(suggestion[1])
                                    toast.success(`Selected AI suggestion #${index + 1}`)
                                  }}
                                  size="sm"
                                  className="flex-1 bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-white text-xs h-9"
                                >
                                  <Scissors className="w-3 h-3 mr-1" />
                                  Use
                                </Button>
                                <Button
                                  onClick={(e) => {
                                    e.stopPropagation()
                                    downloadAISuggestion(suggestion, index)
                                  }}
                                  size="sm"
                                  variant="outline"
                                  className="flex-1 border-yellow-500/30 hover:bg-yellow-500/20 hover:border-yellow-500/50 text-white text-xs h-9"
                                >
                                  <Download className="w-3 h-3 mr-1" />
                                  Download
                                </Button>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </ScrollArea>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-white/10 bg-black/30 backdrop-blur-xl mt-auto">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col items-center gap-4">
            <div className="flex items-center gap-2">
              <div className="bg-gradient-to-r from-purple-500 to-pink-500 p-1.5 rounded-lg">
                <Youtube className="w-4 h-4 text-white" />
              </div>
              <p className="text-purple-300/70 text-sm font-medium">ClipStudio</p>
            </div>
            <div className="flex items-center gap-6 text-purple-300/50 text-sm flex-wrap justify-center">
              <span className="flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-yellow-400" />
                AI-Powered
              </span>
              <span className="flex items-center gap-1.5">
                <Video className="w-3.5 h-3.5 text-purple-400" />
                Ad-Free
              </span>
              <span className="flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-pink-400" />
                Smart Clips
              </span>
            </div>
            <div className="text-purple-300/40 text-sm">
              Developed by <span className="text-purple-300/70 font-semibold">Humnath Pokharel</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
